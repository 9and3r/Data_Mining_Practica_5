package Datos;



import java.io.FileWriter;
import java.io.PrintWriter;

import weka.classifiers.Evaluation;
import weka.classifiers.bayes.NaiveBayes;

public class Main {
	
	///home/euiti/Escritorio/train.e2e.wOOV.obfuscated.arff 1 /home/euiti/Escritorio/dev.e2e.wOOV.obfuscated.arff /home/euiti/Escritorio/modelo.mdl
	
	//args[0]	--> path train
	//args[1]	--> posición class
	//args[2]	--> path dev
	//args[3]	--> path mdl salida --> no es necesario --> por defecto path de train
									
	
	
	public static void main(String[] args) {
		
			
		String pathmdl="";
		String pathtxt="";
		
		//ficheros de salida por defecto
		
		if(args.length==3){
			
		
			String a = args[0];
			String[] path = a.split("/");
			int i = path.length;
				
			for(int j=0;j<i-1;j++){
				if(j!=(i-1)){
					pathmdl = pathmdl + path[j] + "/";
				}
				else{
					pathmdl = pathmdl + path[j];
				}
			}	
		
		pathtxt = pathmdl + "evaluacion.txt";
		pathmdl = pathmdl + "modelo.mdl";
		
		}
		
		else{
			//ficheros de salida por parapetro
			if(args.length==4){
				pathmdl = args[3];
			
				String a = args[3];
				String[] path = a.split("/");
				int i = path.length;
				
				for(int j=0;j<i-1;j++){
					if(j!=(i-1)){
						pathtxt = pathtxt + path[j] + "/";
					}
					else{
						pathtxt = pathtxt + path[j];
					}
				}
				pathtxt = pathtxt+"evaluacion.txt";
			}
			else{
				System.out.println("numero de argumentos incorrecto!!!\ndebe tener la siguiente estructura:\n/home/euiti/Escritorio/train.e2e.wOOV.obfuscated.arff 1 /home/euiti/Escritorio/dev.e2e.wOOV.obfuscated.arff /home/euiti/Escritorio/modelo.mdl\nargs[0]	--> path train\nargs[1]	--> posición class\nargs[2]	--> path dev\nargs[3] --> path mdl salida --> no es necesario --> por defecto path de train");
				
				System.exit(1);
	
			}
		}
		
		//cargar train y dev
		
		DatuKargatzaile train = new DatuKargatzaile(args[0]);
		DatuKargatzaile dev = new DatuKargatzaile(args[2]);
		train.setKlasearenPosizioa(Integer.valueOf(args[1]));
		dev.setKlasearenPosizioa(Integer.valueOf(args[1]));
		
		
		
		NaiveBayes nb = new NaiveBayes();
		
		try {
			nb.buildClassifier(train.getInstantziak());
			Evaluation eval = new Evaluation(train.getInstantziak());
			eval.evaluateModel(nb, dev.getInstantziak());
			System.out.println("archivos de salida -->   " + pathmdl + "   y   " + pathtxt);
			System.out.println(eval.toSummaryString());
			
			
			//llenar txt
			
			FileWriter fitxategia = new FileWriter(pathtxt);
			PrintWriter pw = new PrintWriter(fitxategia);
			pw.println(eval.toSummaryString());
			pw.close();
			
			//llenar modelo
			weka.core.SerializationHelper.write(pathmdl, nb);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	

}
